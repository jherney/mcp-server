import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, writeFile, symlink, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

let dir, outside, client;
const text = (r) => r.content.map((c) => c.text).join("");
const call = (name, args) => client.callTool({ name, arguments: args });

before(async () => {
  dir = await mkdtemp(path.join(tmpdir(), "ws-"));
  outside = await mkdtemp(path.join(tmpdir(), "outside-"));
  await writeFile(path.join(outside, "secret.txt"), "TOP SECRET");
  await mkdir(path.join(dir, "src/components"), { recursive: true });
  await writeFile(path.join(dir, "README.md"), "# Hello\nworld");
  await writeFile(path.join(dir, "src/app.ts"), "export const answer = 42;\n");
  await writeFile(path.join(dir, "src/components/Button.tsx"), "export function Button() { return null; }\n");
  await symlink(outside, path.join(dir, "escape"));
  client = new Client({ name: "test", version: "0" });
  await client.connect(new StdioClientTransport({ command: "node", args: ["dist/index.js", dir], stderr: "ignore" }));
});
after(() => client?.close());

test("lists tools", async () => {
  const { tools } = await client.listTools();
  assert.deepEqual(tools.map((t) => t.name).sort(), ["get_file_info", "list_directory", "read_file", "search_files", "write_file"]);
});

test("reads and lists", async () => {
  assert.equal(text(await call("read_file", { path: "README.md" })), "# Hello\nworld");
  assert.match(text(await call("list_directory", {})), /\[dir\]  src\//);
});

test("search by glob and content", async () => {
  assert.equal(text(await call("search_files", { pattern: "*.tsx" })), "src/components/Button.tsx");
  assert.equal(text(await call("search_files", { pattern: "src/**/*.ts" })), "src/app.ts");
  assert.match(text(await call("search_files", { pattern: "*", contains: "ANSWER" })), /src\/app\.ts:1: export const answer/);
});

test("writes, refuses overwrite without flag", async () => {
  assert.match(text(await call("write_file", { path: "new/dir/x.txt", content: "hi" })), /Created new\/dir\/x.txt/);
  assert.equal(await readFile(path.join(dir, "new/dir/x.txt"), "utf8"), "hi");
  const r = await call("write_file", { path: "new/dir/x.txt", content: "bye" });
  assert.equal(r.isError, true);
  assert.match(text(await call("write_file", { path: "new/dir/x.txt", content: "bye", overwrite: true })), /Overwrote/);
});

test("blocks escapes", async () => {
  for (const p of ["../outside.txt", "/etc/passwd", "escape/secret.txt", "src/../../x"]) {
    const r = await call("read_file", { path: p });
    assert.equal(r.isError, true, p);
    assert.doesNotMatch(text(r), /TOP SECRET|root:/, p);
  }
  const w = await call("write_file", { path: "escape/pwned.txt", content: "x" });
  assert.equal(w.isError, true);
});

test("resources", async () => {
  const { resources } = await client.listResources();
  assert.ok(resources.some((r) => r.uri === "config://settings"));
  assert.ok(resources.some((r) => r.uri === "workspace:///README.md"));
  const r = await client.readResource({ uri: "workspace:///src/app.ts" });
  assert.match(r.contents[0].text, /answer = 42/);
});

test("read-only mode hides write_file", async () => {
  const c = new Client({ name: "ro", version: "0" });
  await c.connect(new StdioClientTransport({ command: "node", args: ["dist/index.js", dir], env: { ...process.env, MCP_READ_ONLY: "true" }, stderr: "ignore" }));
  const { tools } = await c.listTools();
  assert.ok(!tools.some((t) => t.name === "write_file"));
  await c.close();
});
